import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Users, TrendingUp, AlertTriangle, BarChart2,
  Trash2, Edit, Plus, X, Loader2, ChevronDown,
  CheckCircle2, AlertCircle, RefreshCw,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { API_BASE_URL } from '../utils/api';

const CAT_COLORS: Record<string, string> = { High: '#10b981', Medium: '#3b82f6', Low: '#f59e0b' };

export default function AdminPanel() {
  const { token } = useAuth();
  const [students, setStudents]     = useState<any[]>([]);
  const [stats, setStats]           = useState<any>(null);
  const [recs, setRecs]             = useState<any[]>([]);
  const [tab, setTab]               = useState<'overview'|'students'|'recommendations'>('overview');
  const [loading, setLoading]       = useState(true);
  const [filter, setFilter]         = useState<string>('All');
  const [showForm, setShowForm]     = useState(false);
  const [editing, setEditing]       = useState<any>(null);
  const [formData, setFormData]     = useState({ target_category:'All', title:'', content:'' });
  const [saving, setSaving]         = useState(false);
  const [error, setError]           = useState('');

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [studRes, statsRes, recsRes] = await Promise.all([
        fetch(`${API_BASE_URL}/api/performance/all`,   { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/api/performance/stats`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_BASE_URL}/api/recommendations`,   { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      if (studRes.ok)  setStudents(await studRes.json());
      if (statsRes.ok) setStats(await statsRes.json());
      if (recsRes.ok)  setRecs(await recsRes.json());
    } catch(e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (token) fetchAll(); }, [token]);

  const filteredStudents = filter === 'All' ? students : students.filter(s => s.category === filter);

  const pieData = stats ? Object.entries(stats.categoryDistribution || {}).map(([name, value]) => ({ name, value })) : [];

  const openEdit = (rec: any) => {
    setEditing(rec);
    setFormData({ target_category: rec.target_category, title: rec.title, content: rec.content });
    setShowForm(true);
  };
  const openNew = () => {
    setEditing(null);
    setFormData({ target_category: 'All', title: '', content: '' });
    setShowForm(true);
  };

  const saveRec = async () => {
    setSaving(true); setError('');
    try {
      const url = editing
        ? `${API_BASE_URL}/api/recommendations/${editing.id}`
        : `${API_BASE_URL}/api/recommendations`;
      const res = await fetch(url, {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(formData),
      });
      if (!res.ok) throw new Error('Failed to save');
      await fetchAll();
      setShowForm(false);
    } catch (e: any) { setError(e.message); }
    finally { setSaving(false); }
  };

  const deleteRec = async (id: number) => {
    if (!confirm('Delete this recommendation?')) return;
    await fetch(`${API_BASE_URL}/api/recommendations/${id}`, {
      method: 'DELETE', headers: { Authorization: `Bearer ${token}` },
    });
    fetchAll();
  };

  const TabBtn = ({ id, label, icon }: any) => (
    <button onClick={() => setTab(id)}
      className={`flex items-center gap-2 px-5 py-3 rounded-xl font-black text-sm transition-all ${tab === id ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-white text-slate-500 border border-slate-100 hover:border-blue-200 hover:text-blue-600'}`}>
      {icon}{label}
    </button>
  );

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-24 gap-4">
      <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      <p className="text-slate-500 font-bold">Loading admin data...</p>
    </div>
  );

  return (
    <div className="space-y-6 pb-10">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Admin Panel</h2>
          <p className="text-slate-500 font-medium mt-1">Monitor all student performance and manage recommendations.</p>
        </div>
        <button onClick={fetchAll} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl font-black text-slate-600 hover:border-blue-300 transition-all text-sm">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-3">
        <TabBtn id="overview"         label="Overview"         icon={<BarChart2 className="w-4 h-4" />} />
        <TabBtn id="students"         label="Students"         icon={<Users className="w-4 h-4" />} />
        <TabBtn id="recommendations"  label="Recommendations"  icon={<CheckCircle2 className="w-4 h-4" />} />
      </div>

      {/* ─── OVERVIEW ─── */}
      {tab === 'overview' && (
        <div className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label:'Total Students',  value: stats?.totalStudents || 0,       icon:<Users className="w-6 h-6 text-blue-600"  />, bg:'from-blue-50 to-blue-100/50'     },
              { label:'Avg GPA',          value: `${stats?.avgGpa || 0} / 10`,   icon:<TrendingUp className="w-6 h-6 text-emerald-600" />, bg:'from-emerald-50 to-emerald-100/50' },
              { label:'Alerts',           value: stats?.alerts?.length || 0,     icon:<AlertTriangle className="w-6 h-6 text-amber-600" />, bg:'from-amber-50 to-amber-100/50' },
              { label:'High Performers',  value: stats?.categoryDistribution?.High || 0, icon:<CheckCircle2 className="w-6 h-6 text-purple-600" />, bg:'from-purple-50 to-purple-100/50' },
            ].map(c => (
              <div key={c.label} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{c.label}</p>
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.bg} flex items-center justify-center`}>{c.icon}</div>
                </div>
                <p className="text-3xl font-black text-slate-900">{c.value}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pie Chart */}
            <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 mb-4">Performance Distribution</h3>
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie 
                      data={pieData} 
                      dataKey="value" 
                      nameKey="name" 
                      cx="50%" 
                      cy="50%" 
                      outerRadius={80}
                      label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((e,i) => <Cell key={i} fill={CAT_COLORS[e.name]||'#94a3b8'} />)}
                    </Pie>
                    <Tooltip /><Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : <p className="text-center py-16 text-slate-400 font-bold italic">No prediction data yet.</p>}
            </div>

            {/* Alerts */}
            <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" /> Risk Alerts
              </h3>
              {stats?.alerts?.length > 0 ? (
                <div className="space-y-3">
                  {stats.alerts.map((a: any, i: number) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <div className={`w-2 h-10 rounded-full shrink-0 ${a.severity === 'high' ? 'bg-red-500' : 'bg-amber-500'}`} />
                      <div>
                        <p className="text-sm font-black text-slate-800">{a.name}</p>
                        <p className="text-xs font-medium text-slate-500">{a.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : <p className="text-center py-10 text-slate-400 font-bold italic">No alerts.</p>}
            </div>
          </div>
        </div>
      )}

      {/* ─── STUDENTS ─── */}
      {tab === 'students' && (
        <div className="space-y-4">
          {/* Filter */}
          <div className="flex flex-wrap gap-2">
            {['All','High','Medium','Low'].map(f => (
              <button key={f} onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-xl font-black text-sm transition-all ${filter === f ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-blue-300'}`}>
                {f}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    {['Student','GPA','Score','Category','Attendance','Study Hrs','Submitted'].map(h => (
                      <th key={h} className="px-5 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredStudents.length > 0 ? filteredStudents.map((s, i) => (
                    <tr key={i} className="hover:bg-slate-50/50 transition-all">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-black text-sm">{s.name?.[0]}</div>
                          <div>
                            <p className="font-black text-slate-800">{s.name}</p>
                            <p className="text-[10px] text-slate-400">{s.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4 font-black text-blue-600">{s.gpa || '—'}</td>
                      <td className="px-5 py-4 font-black text-slate-700">{s.predicted_score || '—'}</td>
                      <td className="px-5 py-4">
                        {s.category ? (
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                            s.category==='High' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                            s.category==='Medium' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                            'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>{s.category}</span>
                        ) : '—'}
                      </td>
                      <td className="px-5 py-4 font-semibold text-slate-600">{s.attendance != null ? `${(s.attendance*100).toFixed(0)}%` : '—'}</td>
                      <td className="px-5 py-4 font-semibold text-slate-600">{s.study_hours != null ? `${s.study_hours}h/day` : '—'}</td>
                      <td className="px-5 py-4 text-slate-400">{new Date(s.created_at).toLocaleDateString()}</td>
                    </tr>
                  )) : (
                    <tr><td colSpan={7} className="py-16 text-center text-slate-400 font-bold italic">No students found for this filter.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ─── RECOMMENDATIONS ─── */}
      {tab === 'recommendations' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 font-medium">{recs.length} custom recommendations</p>
            <button onClick={openNew}
              className="flex items-center gap-2 px-5 py-3 bg-blue-600 text-white font-black rounded-xl shadow-lg shadow-blue-500/20 hover:-translate-y-0.5 transition-all text-sm">
              <Plus className="w-4 h-4" /> Add Recommendation
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recs.length > 0 ? recs.map(rec => (
              <div key={rec.id} className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:border-blue-200 transition-all">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mr-2 ${
                      rec.target_category==='High' ? 'bg-emerald-50 text-emerald-700' :
                      rec.target_category==='Medium' ? 'bg-blue-50 text-blue-700' :
                      rec.target_category==='Low'  ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-600'
                    }`}>{rec.target_category}</span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(rec)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteRec(rec.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <h4 className="font-black text-slate-900 mb-2">{rec.title}</h4>
                <p className="text-sm text-slate-600 font-medium leading-relaxed">{rec.content}</p>
                <p className="text-[10px] text-slate-400 mt-3 uppercase tracking-widest">By {rec.teacher_name}</p>
              </div>
            )) : (
              <div className="md:col-span-2 py-16 text-center text-slate-400 font-bold italic">
                No custom recommendations yet. Add one to guide students!
              </div>
            )}
          </div>
        </div>
      )}

      {/* ─── REC MODAL ─── */}
      {showForm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl relative z-10 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-900">{editing ? 'Edit' : 'New'} Recommendation</h3>
              <button onClick={() => setShowForm(false)} className="p-2 text-slate-400 hover:text-slate-700 rounded-xl transition-all"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-600 text-sm">
                  <AlertCircle className="w-4 h-4 shrink-0" /><span className="font-bold">{error}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-1.5">Target Category</label>
                <div className="relative">
                  <select value={formData.target_category} onChange={e => setFormData(p => ({...p, target_category: e.target.value}))}
                    className="w-full px-4 py-3 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-xl outline-none font-semibold text-slate-800 text-sm appearance-none">
                    {['All','Low','Medium','High'].map(c => <option key={c}>{c}</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-1.5">Title</label>
                <input value={formData.title} onChange={e => setFormData(p => ({...p, title: e.target.value}))}
                  className="w-full px-4 py-3 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-xl outline-none font-semibold text-slate-800 text-sm"
                  placeholder="e.g. Learn DSA this semester" />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-1.5">Content</label>
                <textarea rows={4} value={formData.content} onChange={e => setFormData(p => ({...p, content: e.target.value}))}
                  className="w-full px-4 py-3 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-xl outline-none font-semibold text-slate-800 text-sm resize-none"
                  placeholder="Write your recommendation here..." />
              </div>
            </div>
            <div className="p-6 pt-0 flex gap-3">
              <button onClick={() => setShowForm(false)} className="flex-1 py-3 bg-slate-100 text-slate-700 font-black rounded-xl hover:bg-slate-200 transition-all text-sm">Cancel</button>
              <button onClick={saveRec} disabled={saving}
                className="flex-1 py-3 bg-blue-600 text-white font-black rounded-xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all text-sm disabled:opacity-60 flex items-center justify-center gap-2">
                {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</> : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
