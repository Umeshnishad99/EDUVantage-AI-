import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LogOut, BookOpen, BrainCircuit, TrendingUp, Sparkles, X,
  CheckCircle2, MapPin, Loader2, Award,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';

const CAT_STYLE: Record<string, { badge: string; dot: string; title: string }> = {
  High:    { badge: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500', title: 'High Performance 🏆' },
  Medium:  { badge: 'bg-blue-50    text-blue-700    border-blue-200',    dot: 'bg-blue-500',    title: 'Medium Performance 📈' },
  Low:     { badge: 'bg-amber-50   text-amber-700   border-amber-200',   dot: 'bg-amber-500',   title: 'Needs Improvement 📚' },
  Unknown: { badge: 'bg-slate-50   text-slate-600   border-slate-200',   dot: 'bg-slate-400',   title: 'Pending' },
};

export default function StudentDashboard() {
  const { logout, token, user } = useAuth();
  const navigate = useNavigate();
  const [data, setData]     = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showRec, setShowRec]   = useState(false);
  const [showRoad, setShowRoad] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const apiBaseUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000';
        const res = await fetch(`${apiBaseUrl}/api/performance/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          setData(await res.json());
        } else {
          navigate('/student/form');
        }
      } catch {
        navigate('/student/form');
      } finally {
        setLoading(false);
      }
    })();
  }, [token, navigate]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
        <p className="text-slate-600 font-bold">Loading your analysis...</p>
      </div>
    </div>
  );

  const perf = data?.performance;
  const pred = data?.prediction;
  const cat  = CAT_STYLE[pred?.category || 'Unknown'];

  const recs: string[] = pred
    ? (Array.isArray(pred.recommendations) ? pred.recommendations : JSON.parse(pred.recommendations || '[]'))
    : [];
  const road: string[] = pred
    ? (Array.isArray(pred.roadmap) ? pred.roadmap : JSON.parse(pred.roadmap || '[]'))
    : [];

  const subjectData = perf ? [
    { name: 'Math', score: perf.math },
    { name: 'English', score: perf.english },
    { name: 'Computer', score: perf.computer },
    { name: 'Physics', score: perf.physics },
    { name: 'Chemistry', score: perf.chemistry },
    { name: 'Biology', score: perf.biology },
  ] : [];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans">

      {/* Navbar */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between h-18 items-center py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow">
              <BookOpen className="text-white w-5 h-5" />
            </div>
            <div>
              <div className="font-black text-slate-900 leading-none">EduAI</div>
              <div className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Student Portal</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/student/predict')}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white border border-indigo-700 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all">
              <Sparkles className="w-4 h-4" /> AI Prediction
            </button>
            <button onClick={() => navigate('/student/form')}
              className="hidden sm:flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 border border-blue-100 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-blue-100 transition-all">
              <BrainCircuit className="w-4 h-4" /> Performance Form
            </button>
            <button onClick={() => { logout(); navigate('/login'); }}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-100 hover:bg-red-50 transition-all">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

         {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">
            Welcome back, {user?.name?.split(' ')[0] || 'Student'} 👋
          </h1>
          <p className="text-slate-500 font-medium mt-1">Here's your AI-powered academic performance analysis.</p>
        </div>

        {pred ? (
          <div className="space-y-6">

            {/* KPI Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* GPA Card */}
              <div className="bg-slate-900 text-white rounded-[2rem] p-6 relative overflow-hidden shadow-2xl">
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl" />
                <div className="relative z-10">
                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Predicted GPA</p>
                  <div className="text-6xl font-black tracking-tighter text-white leading-none">
                    {pred.gpa}
                  </div>
                  <p className="text-slate-400 font-bold text-xs mt-2">Out of 10.0</p>
                </div>
              </div>

              {/* Score Card */}
              <div className="bg-white rounded-[2rem] p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Predicted Score</p>
                <div className="text-5xl font-black text-blue-600 tracking-tighter">{pred.predicted_score}</div>
                <div className="h-2 bg-slate-100 rounded-full mt-3">
                  <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${pred.predicted_score}%` }} />
                </div>
              </div>

              {/* Category Card */}
              <div className="bg-white rounded-[2rem] p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Category</p>
                <div className="flex items-center gap-3 mb-4">
                  <span className={`w-3 h-3 rounded-full ${cat.dot}`} />
                  <span className="text-xl font-black text-slate-900">{cat.title}</span>
                </div>
                <span className={`self-start px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${cat.badge}`}>
                  {pred.category}
                </span>
              </div>
            </div>

            {/* Actions Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button onClick={() => setShowRec(true)}
                className="flex items-center justify-center gap-3 py-5 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-500/20 hover:shadow-indigo-500/40 hover:-translate-y-0.5 transition-all active:scale-95">
                <CheckCircle2 className="w-6 h-6" /> View Recommendations
              </button>
              <button onClick={() => setShowRoad(true)}
                className="flex items-center justify-center gap-3 py-5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black rounded-2xl shadow-xl shadow-emerald-500/20 hover:shadow-emerald-500/40 hover:-translate-y-0.5 transition-all active:scale-95">
                <MapPin className="w-6 h-6" /> View Career Roadmap
              </button>
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Subject Bar Chart */}
              <div className="bg-white rounded-[2rem] p-6 md:p-8 border border-slate-100 shadow-sm">
                <h3 className="text-xl font-black text-slate-900 mb-4 flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-blue-600" /> Performance Overview
                </h3>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={subjectData} barSize={38} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fontWeight: 700 }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0,100]} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                    <RechartsTooltip formatter={(v) => [`${v}%`, 'Score']} cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="score" fill="#6366f1" radius={[8,8,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Subject Radar Chart */}
              <div className="bg-white rounded-[2rem] p-6 md:p-8 border border-slate-100 shadow-sm">
                <h3 className="text-xl font-black text-slate-900 mb-4 flex items-center gap-3">
                  <BrainCircuit className="w-5 h-5 text-emerald-600" /> Skill Analysis
                </h3>
                <ResponsiveContainer width="100%" height={260}>
                  <RadarChart cx="50%" cy="50%" outerRadius="75%" data={subjectData}>
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey="name" tick={{ fill: '#475569', fontSize: 11, fontWeight: 700 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                    <Radar name="Student" dataKey="score" stroke="#10b981" fill="#10b981" fillOpacity={0.4} />
                    <RechartsTooltip formatter={(v) => [`${v}%`, 'Score']} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: 'Attendance',       value: `${(Number(perf?.attendance||0)*100).toFixed(0)}%` },
                { label: 'Study Hrs/Day',    value: `${perf?.study_hours}h` },
                { label: 'Parent Support',   value: `${perf?.parent_support}/5` },
                { label: 'Internet Access',  value: perf?.internet_access ? 'Yes' : 'No' },
              ].map(item => (
                <div key={item.label} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm text-center">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{item.label}</p>
                  <p className="text-2xl font-black text-slate-900">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-20 h-20 bg-blue-50 rounded-3xl flex items-center justify-center mb-6">
              <Award className="w-10 h-10 text-blue-300" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-2">No Prediction Yet</h2>
            <p className="text-slate-500 font-medium mb-6">Submit your performance data to get AI predictions and career guidance.</p>
            <button onClick={() => navigate('/student/form')}
              className="px-8 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:-translate-y-0.5 transition-all">
              Fill Performance Form
            </button>
          </div>
        )}
      </main>

      {/* Recommendations Modal */}
      {showRec && (
        <Modal title="AI Recommendations" icon={<CheckCircle2 className="w-6 h-6 text-white" />} color="bg-indigo-600" onClose={() => setShowRec(false)}>
          {recs.length > 0 ? (
            <ul className="space-y-3">
              {recs.map((r,i) => (
                <li key={i} className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                  <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                  <span className="text-sm font-medium text-slate-700">{r}</span>
                </li>
              ))}
            </ul>
          ) : <p className="text-slate-400 text-center py-8 font-bold">No recommendations available.</p>}
        </Modal>
      )}

      {/* Roadmap Modal */}
      {showRoad && (
        <Modal title="Career Roadmap" icon={<Sparkles className="w-6 h-6 text-white" />} color="bg-emerald-600" onClose={() => setShowRoad(false)}>
          {road.length > 0 ? (
            <ol className="relative border-l-2 border-slate-200 space-y-5 ml-3">
              {road.map((step,i) => (
                <li key={i} className="ml-5">
                  <span className="absolute -left-3.5 flex items-center justify-center w-7 h-7 rounded-full bg-emerald-500 text-white font-black text-xs border-2 border-white">{i+1}</span>
                  <p className="text-sm font-medium text-slate-700 pt-0.5">{step}</p>
                </li>
              ))}
            </ol>
          ) : <p className="text-slate-400 text-center py-8 font-bold">No roadmap available.</p>}
        </Modal>
      )}
    </div>
  );
}

function Modal({ title, icon, color, onClose, children }: any) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className="bg-white w-full max-w-lg rounded-[2rem] shadow-2xl relative z-10 overflow-hidden max-h-[85vh] flex flex-col">
        <div className={`${color} p-6 flex items-center justify-between shrink-0`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">{icon}</div>
            <h3 className="text-lg font-black text-white">{title}</h3>
          </div>
          <button onClick={onClose} className="p-2 text-white/70 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
