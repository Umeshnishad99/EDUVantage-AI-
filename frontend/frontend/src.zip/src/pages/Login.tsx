import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { BookOpen, AlertCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { API_BASE_URL } from '../utils/api';

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();

      if (response.ok) {
        login(data);
        if (data.user.role === 'teacher') {
          navigate('/dashboard');
        } else {
          navigate('/student/dashboard');
        }
      } else {
        setError(data.message || 'Invalid credentials');
      }
    } catch (err) {
      setError('Connection error. Is the server running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex text-slate-900 bg-white">
      {/* Left side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 lg:p-24 relative z-10 transition-all">
        <div className="w-full max-w-md mx-auto space-y-8">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                <BookOpen className="text-white w-6 h-6" />
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-800">
                EduAI Predictor
              </h1>
            </div>
            
            <h2 className="text-4xl font-extrabold tracking-tight mb-2 text-slate-900">
              Welcome back
            </h2>
            <p className="text-slate-500 text-lg">
              Sign in to analyze student performances and explore predictive insights.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6 mt-8">
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl flex items-center gap-3 animate-pulse">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-medium text-slate-800"
                  placeholder="teacher@school.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-medium text-slate-800"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 transition-colors cursor-pointer" />
                <span className="text-sm font-medium text-slate-600">Remember me</span>
              </label>
              <a href="#" className="text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors">
                Forgot password?
              </a>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-4 px-8 rounded-xl font-bold text-lg shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 transition-all hover:-translate-y-0.5 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? 'Signing in...' : 'Sign In to Dashboard'}
              {!loading && <ArrowRight className="w-5 h-5" />}
            </button>
            
            <p className="text-center text-slate-500 font-medium">
              Don't have an account?{' '}
              <Link to="/register" className="text-blue-600 font-semibold hover:text-blue-700 transition-colors">
                Create one now
              </Link>
            </p>
          </form>
        </div>
      </div>

      {/* Right side - Visual/Hero */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-900 overflow-hidden items-center justify-center">
        {/* Background Gradients */}
        <div className="absolute top-0 -left-1/4 w-[150%] h-[150%] bg-gradient-to-br from-blue-600/20 via-indigo-600/20 to-purple-600/20 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-0 right-0 w-full h-1/2 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent z-10" />

        <div className="relative z-20 max-w-lg px-12 text-center text-white space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-blue-300 text-sm font-semibold mb-4 mx-auto">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            AI Prediction Engine v2.0 Live
          </div>
          
          <h2 className="text-5xl font-bold leading-tight">
            Predict & Improve <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Student Futures
            </span>
          </h2>
          
          <p className="text-lg text-slate-400 leading-relaxed font-medium">
            Analyze historical academic data, behavioral patterns, and attendance records to forecast GPA and offer personalized improvement recommendations using our Scikit-Learn machine learning pipeline.
          </p>

          <div className="pt-8 grid grid-cols-2 gap-4">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl text-left">
              <p className="text-3xl font-bold text-white mb-1">94%</p>
              <p className="text-sm font-medium text-slate-400">Prediction Accuracy</p>
            </div>
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl text-left">
              <p className="text-3xl font-bold text-white mb-1">10x</p>
              <p className="text-sm font-medium text-slate-400">Faster Intervention</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
