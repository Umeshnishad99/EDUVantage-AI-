import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { Users, TrendingUp, AlertTriangle, Bell, UserPlus, ArrowRight, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { API_BASE_URL } from '../utils/api';

const PIE_COLORS: Record<string, string> = {
  High:    '#10b981',
  Medium:  '#3b82f6',
  Low:     '#f59e0b',
  Unknown: '#94a3b8',
};

const Overview = () => {
  const { token } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/performance/stats`, {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (res.ok) setStats(await res.json());
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (token) fetchStats();
  }, [token]);

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      <p className="text-slate-500 font-bold">Aggregating institutional data...</p>
    </div>
  );

  // Pie chart data for performance distribution
  const dist = stats?.categoryDistribution || {};
  const pieData = Object.entries(dist).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-6 md:space-y-10 pb-10">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 md:gap-8">
        <StatCard title="Total Students"   value={stats?.totalStudents?.toLocaleString() || '0'}  trend="Real-time count"       icon={<Users         className="w-6 h-6 text-blue-600"   />} gradient="from-blue-50 to-blue-100/50"     />
        <StatCard title="Avg Pred. GPA"    value={`${stats?.avgGpa || '0.0'} / 10`}              trend="Institutional Avg"     icon={<TrendingUp     className="w-6 h-6 text-emerald-600"/>} gradient="from-emerald-50 to-emerald-100/50" />
        <StatCard title="Risk Alerts"      value={stats?.alerts?.length.toString() || '0'}          trend="Need Intervention"     icon={<AlertTriangle  className="w-6 h-6 text-amber-600" />} gradient="from-amber-50 to-amber-100/50"    />
        <StatCard title="Active Predictions" value={stats?.totalStudents?.toString() || '0'}         trend="All Time"              icon={<UserPlus       className="w-6 h-6 text-purple-600"/>} gradient="from-purple-50 to-purple-100/50"  />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 md:gap-10">
        <div className="xl:col-span-8 space-y-6 md:space-y-10">
          
          {/* Performance Distribution Large Bar Chart - Alternative View */}
          <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
            <div className="mb-6 md:mb-8">
              <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Performance Statistics</h3>
              <p className="text-sm text-slate-500 font-bold mt-1">GPA distribution across performance categories</p>
            </div>
            {pieData.length === 0 ? (
              <div className="h-48 flex items-center justify-center bg-slate-50/50 rounded-3xl border-2 border-dashed border-slate-100 text-slate-400 font-bold italic text-center p-4">
                No data yet — predictions will populate this chart.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={pieData} barSize={60}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fontWeight: 700 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip cursor={{ fill: '#f8fafc' }} />
                  <Bar dataKey="value" fill="#3b82f6" radius={[12, 12, 0, 0]}>
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[entry.name] || '#3b82f6'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* AI Smart Alerts */}
          <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-6 md:mb-8">
              <h3 className="text-lg md:text-xl font-black text-slate-900 flex items-center gap-3">
                <Bell className="w-6 h-6 text-amber-500" /> AI Risk Alerts
              </h3>
              <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                {stats?.alerts?.length || 0} Critical
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {stats?.alerts?.length > 0 ? stats.alerts.map((alert: any, idx: number) => (
                <div key={idx} className="p-4 md:p-5 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-4 hover:border-blue-200 transition-all cursor-pointer">
                  <div className={`w-2 h-10 rounded-full shrink-0 ${alert.severity === 'high' ? 'bg-red-500' : 'bg-amber-500'}`} />
                  <div>
                    <p className="text-sm font-black text-slate-800">{alert.name}</p>
                    <p className="text-xs font-bold text-slate-500 mt-0.5">{alert.message}</p>
                  </div>
                </div>
              )) : (
                <div className="col-span-2 py-10 text-center text-slate-400 font-bold italic">No critical alerts detected.</div>
              )}
            </div>
          </div>
        </div>

        <div className="xl:col-span-4 space-y-6 md:space-y-10">

          {/* Performance Distribution Pie */}
          <div className="bg-white p-6 md:p-8 rounded-[2rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
            <h3 className="text-lg font-black text-slate-900 mb-6 tracking-tight">Distribution</h3>
            {pieData.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-slate-400 font-bold italic text-sm text-center">
                No predictions yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={PIE_COLORS[entry.name] || '#94a3b8'} />
                    ))}
                  </Pie>
                  <Legend />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Newly Registered / Recent Activity */}
          <div className="bg-slate-900 rounded-[2rem] md:rounded-[2.5rem] p-6 md:p-10 text-white flex flex-col shadow-2xl shadow-slate-300">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black flex items-center gap-3">
                <TrendingUp className="w-7 h-7 text-blue-400" /> Recent Activity
              </h3>
            </div>
            <div className="space-y-4 flex-1">
              {stats?.recentStudents?.length > 0 ? stats.recentStudents.map((student: any, idx: number) => (
                <div key={idx} className="group flex items-center justify-between bg-white/5 p-4 md:p-5 rounded-[1.5rem] border border-white/5 hover:bg-white/10 transition-all cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-tr from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center font-black text-lg shadow-lg">
                      {student.name[0]}
                    </div>
                    <div>
                      <p className="text-sm font-black text-white">{student.name}</p>
                      <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">{student.category} / GPA {student.gpa}</p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-white transition-colors" />
                </div>
              )) : (
                <div className="py-10 text-center text-slate-500 font-bold italic border-t border-white/5">No recent activity.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, trend, icon, gradient }: { title: string; value: string; trend: string; icon: React.ReactNode; gradient: string }) => (
  <div className="bg-white p-6 md:p-8 rounded-[2rem] shadow-sm border border-slate-100 flex flex-col justify-between hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-500 group">
    <div className="flex justify-between items-start">
      <div className="space-y-1">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.15em]">{title}</p>
        <h4 className="text-3xl font-black text-slate-900 tracking-tighter">{value}</h4>
      </div>
      <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-500`}>
        {icon}
      </div>
    </div>
    <div className="mt-6 flex items-center gap-2">
      <div className="flex h-6 px-3 items-center bg-slate-50 border border-slate-100 rounded-full text-[10px] font-black text-slate-600 uppercase tracking-widest">
        {trend}
      </div>
    </div>
  </div>
);

export default Overview;
