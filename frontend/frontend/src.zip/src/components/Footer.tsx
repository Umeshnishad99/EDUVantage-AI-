import { BookOpen, Github, Twitter, Linkedin, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-white border-t border-slate-200 pt-16 pb-8 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1 border-b border-slate-100 pb-8 md:border-none md:pb-0">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <BookOpen className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tight">EduAI</span>
            </div>
            <p className="text-slate-500 text-sm font-medium leading-relaxed mb-6">
              Empowering students with AI-driven academic insights and personalized career roadmaps for a brighter future.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-blue-50 hover:text-blue-600 transition-all border border-slate-100">
                <Github className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-blue-50 hover:text-blue-600 transition-all border border-slate-100">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-blue-50 hover:text-blue-600 transition-all border border-slate-100">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em] mb-6">Platform</h4>
            <ul className="space-y-4">
              <li><a href="/" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Home</a></li>
              <li><a href="/student/dashboard" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Dashboard</a></li>
              <li><a href="/student/form" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Performance Form</a></li>
              <li><a href="/student/predict" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Quick Prediction</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em] mb-6">Resources</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Documentation</a></li>
              <li><a href="#" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Help Center</a></li>
              <li><a href="#" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-slate-500 hover:text-blue-600 text-sm font-bold transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em] mb-6">Contact Us</h4>
            <p className="text-slate-500 text-sm font-medium mb-6">
              Have questions? Reach out to our support team anytime.
            </p>
            <a href="mailto:support@eduai.com" className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 hover:bg-white transition-all group">
              <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all">
                <Mail className="w-5 h-5" />
              </div>
              <span className="text-sm font-black text-slate-700">support@eduai.com</span>
            </a>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-xs font-bold">
            &copy; {new Date().getFullYear()} EduAI. All rights reserved.
          </p>
          <div className="flex gap-8">
            <span className="text-slate-400 text-xs font-black uppercase tracking-widest cursor-pointer hover:text-slate-600 transition-colors">Made for Students</span>
            <span className="text-slate-400 text-xs font-black uppercase tracking-widest cursor-pointer hover:text-slate-600 transition-colors">AI v2.0</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
