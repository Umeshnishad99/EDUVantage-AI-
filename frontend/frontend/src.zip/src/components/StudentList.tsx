import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, Filter, MoreHorizontal, User, Loader2 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { API_BASE_URL } from '../utils/api';

interface Student {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  predicted_gpa_4: number;
  predicted_gpa_10: number;
}

const StudentList = () => {
  const navigate = useNavigate();
  const { token } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/students`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.ok) {
          const data = await response.json();
          setStudents(data);
        }
      } catch (err) {
        console.error('Failed to load students:', err);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchStudents();
  }, [token]);

  const filteredStudents = students.filter(s => 
    `${s.first_name} ${s.last_name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      <p className="text-slate-500 font-bold">Loading student directory...</p>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Student Directory</h2>
          <p className="text-xs md:text-sm font-bold text-slate-500 mt-1">Manage and track individual findings</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search by name..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-slate-100 rounded-2xl bg-white focus:border-blue-500 outline-none font-bold text-sm text-slate-700 transition-all"
            />
          </div>
          <button className="w-full sm:w-auto p-3 border-2 border-slate-100 rounded-2xl bg-white text-slate-600 hover:bg-slate-50 transition-all shadow-sm flex items-center justify-center gap-2">
            <Filter className="w-5 h-5" />
            <span className="sm:hidden font-bold">Filters</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[1.5rem] md:rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
                <th className="p-4 md:p-6 pl-6 md:pl-8">Student Profile</th>
                <th className="p-4 md:p-6">4.0 GPA</th>
                <th className="p-4 md:p-6">10.0 GPA</th>
                <th className="p-4 md:p-6">Status</th>
                <th className="p-4 md:p-6 text-right pr-6 md:pr-8">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredStudents.length > 0 ? filteredStudents.map((student) => (
                <tr 
                  key={student.id} 
                  className="hover:bg-blue-50/30 transition-all cursor-pointer group"
                  onClick={() => navigate(`/dashboard/students/${student.id}`)}
                >
                  <td className="p-4 md:p-6 pl-6 md:pl-8">
                    <div className="flex items-center gap-3 md:gap-4">
                      <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-slate-100 flex items-center justify-center border-2 border-transparent text-slate-500 group-hover:bg-white group-hover:text-blue-600 group-hover:border-blue-100/50 transition-all">
                        <User className="w-5 h-5 md:w-6 md:h-6" />
                      </div>
                      <div className="flex flex-col">
                        <span className="font-black text-slate-900 group-hover:text-blue-600 transition-colors uppercase tracking-tight text-sm md:text-base">{student.first_name} {student.last_name}</span>
                        <span className="text-[10px] md:text-xs font-bold text-slate-400 truncate max-w-[120px] md:max-w-none">{student.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 md:p-6">
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-blue-500 animate-pulse" />
                      <span className="font-black text-slate-900 text-base md:text-lg">
                        {student.predicted_gpa_4 ? student.predicted_gpa_4.toFixed(2) : 'N/A'}
                      </span>
                    </div>
                  </td>
                  <td className="p-4 md:p-6">
                    <span className="font-black text-slate-400 text-xs md:text-sm">
                      {student.predicted_gpa_10 ? student.predicted_gpa_10.toFixed(1) : 'N/A'}
                    </span>
                  </td>
                  <td className="p-4 md:p-6">
                    <span className={`px-3 py-1 md:px-4 md:py-1.5 rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-widest border ${
                      student.predicted_gpa_4 >= 3.5 ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
                      student.predicted_gpa_4 >= 2.5 ? 'bg-blue-50 text-blue-700 border-blue-100' :
                      'bg-amber-50 text-amber-700 border-amber-100'
                    }`}>
                      {student.predicted_gpa_4 >= 3.5 ? 'Excellent' : student.predicted_gpa_4 >= 2.5 ? 'On Track' : 'Monitor'}
                    </span>
                  </td>
                  <td className="p-4 md:p-6 text-right pr-6 md:pr-8">
                    <button className="p-2 text-slate-300 hover:text-blue-600 transition-all">
                      <MoreHorizontal className="w-5 h-5 md:w-6 md:h-6" />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                   <td colSpan={5} className="p-12 md:p-20 text-center">
                      <p className="text-slate-400 font-bold italic">No students found.</p>
                   </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StudentList;
