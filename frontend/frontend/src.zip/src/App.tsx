import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Register from './pages/Register';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import StudentDashboard from './pages/StudentDashboard';
import PerformanceForm from './pages/PerformanceForm';
import PredictGPA from './pages/PredictGPA';
import Footer from './components/Footer';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
          <div className="flex-1">
            <Routes>
              <Route path="/" element={<Navigate to="/login" replace />} />
              <Route path="/login"    element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Teacher / Admin Routes */}
              <Route path="/dashboard/*" element={
                <ProtectedRoute allowedRole="teacher">
                  <Dashboard />
                </ProtectedRoute>
              } />

              {/* Student: Performance Form */}
              <Route path="/student/form" element={
                <ProtectedRoute allowedRole="student">
                  <PerformanceForm />
                </ProtectedRoute>
              } />

              {/* Student: Predict GPA */}
              <Route path="/student/predict" element={
                <ProtectedRoute allowedRole="student">
                  <PredictGPA />
                </ProtectedRoute>
              } />

              {/* Student: Dashboard */}
              <Route path="/student/dashboard" element={
                <ProtectedRoute allowedRole="student">
                  <StudentDashboard />
                </ProtectedRoute>
              } />

              {/* Catch-all */}
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
